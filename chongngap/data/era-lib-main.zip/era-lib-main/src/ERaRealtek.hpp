#ifndef INC_ERA_REALTEK_HPP_
#define INC_ERA_REALTEK_HPP_

#define ERA_MODBUS

#include <ERaSimpleRealtek.hpp>

#endif /* INC_ERA_REALTEK_HPP_ */
