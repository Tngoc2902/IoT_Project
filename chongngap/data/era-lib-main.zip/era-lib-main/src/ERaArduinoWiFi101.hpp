#ifndef INC_ERA_ARDUINO_WIFI_101_HPP_
#define INC_ERA_ARDUINO_WIFI_101_HPP_

#define ERA_MODBUS

#include <ERaSimpleArduinoWiFi101.hpp>

#endif /* INC_ERA_ARDUINO_WIFI_101_HPP_ */
