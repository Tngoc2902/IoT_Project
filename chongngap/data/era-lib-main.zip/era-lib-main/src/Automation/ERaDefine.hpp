#pragma once

#if !defined(ERA_NOTIFY_DELAY)
    #define ERA_NOTIFY_DELAY        3000UL
#endif
#if !defined(ERA_EMAIL_DELAY)
    #define ERA_EMAIL_DELAY         3000UL
#endif
#if !defined(ERA_WEBHOOK_DELAY)
    #define ERA_WEBHOOK_DELAY       3000UL
#endif
