#ifndef INC_ERA_RP2040_SSL_WIZ_HPP_
#define INC_ERA_RP2040_SSL_WIZ_HPP_

#define ERA_MODBUS
#define ERA_ZIGBEE

#include <ERaSimpleRp2040SSLWiz.hpp>

#endif /* INC_ERA_RP2040_SSL_WIZ_HPP_ */
