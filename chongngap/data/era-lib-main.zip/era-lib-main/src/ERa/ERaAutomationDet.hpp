#ifndef INC_ERA_AUTOMATION_DETECT_HPP_
#define INC_ERA_AUTOMATION_DETECT_HPP_

#if defined(ERA_AUTOMATION)
    #include <ERa/ERaAutomation.hpp>
#endif

#endif /* INC_ERA_AUTOMATION_DETECT_HPP_ */
