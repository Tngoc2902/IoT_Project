#ifndef INC_ERA_SMS_DEFINE_HPP_
#define INC_ERA_SMS_DEFINE_HPP_

#if !defined(ERA_MAX_SMS)
    #define ERA_MAX_SMS     10
#endif

#endif /* INC_ERA_SMS_DEFINE_HPP_ */
