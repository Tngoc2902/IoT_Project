#ifndef INC_ERA_ETHERNET_HPP_
#define INC_ERA_ETHERNET_HPP_

#define ERA_MODBUS
#define ERA_ZIGBEE

#include <ERaSimpleEthernet.hpp>

#endif /* INC_ERA_ETHERNET_HPP_ */
